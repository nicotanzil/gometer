GoMeter / Open Scope

SVG logo masters: gometer-logo-dark.svg, gometer-logo-light.svg,
and gometer-logo-mono.svg. Lettering is outlined; no fonts are needed.
Standalone mark: gometer-mark.svg uses currentColor when inline.
App icon: gometer-app-icon.svg plus 192, 512, 1024px PNG exports.
Favicons: favicon.svg, multi-size favicon.ico, and individual PNGs.
Touch icon: apple-touch-icon.png (180px).

Colors: navy #070a13, signal blue #8db5ff, deep blue #2b56c9,
near-white #e9ecf5. Keep at least one frame-bar width of clear space.
Use the small-size favicon variants at 16 and 24px.

Wordmark derived from the bundled Bricolage Grotesque 600 font.
Font license included. Logo shapes are editable SVG paths.
